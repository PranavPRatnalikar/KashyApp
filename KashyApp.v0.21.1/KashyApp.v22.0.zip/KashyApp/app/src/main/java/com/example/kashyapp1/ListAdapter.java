package com.example.kashyapp1;

import android.app.Activity;
import android.widget.ArrayAdapter;

//public class ListAdapter extends ArrayAdapter {
//
//    private Activity mContext;
//
//    public ListAdapter(){
//
//    }
//}
