package com.example.kashyapp1;

public class MedicalRecordsAdapter {
}
