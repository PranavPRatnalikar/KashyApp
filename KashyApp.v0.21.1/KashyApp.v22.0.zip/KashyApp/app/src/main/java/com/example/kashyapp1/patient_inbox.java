package com.example.kashyapp1;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class patient_inbox extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_patient_inbox);
    }
}